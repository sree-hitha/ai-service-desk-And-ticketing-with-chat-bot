# Relay Service Desk & Support Portal (zero native-dependency edition)

Same app as before — support portal with auth, tickets, and a support
chatbot — but this version has **no native npm packages at all**. It uses
Node's own built-in `node:sqlite` module instead of `better-sqlite3`, so
`npm install` never tries to compile anything. This avoids the Visual
Studio Build Tools requirement that broke the previous version on Windows.

**Requires Node.js 22.13+ or 24+** (run `node --version` to check — SQLite
became a built-in, no-flag-needed module starting at Node 22.13.0 / 23.4.0).

## Stack
- **Backend:** Node.js, Express
- **Database:** SQLite via Node's built-in `node:sqlite` module — creates `relay.db` automatically, no install, no compile, no service
- **Auth:** JWT stored in an HttpOnly cookie, passwords hashed with bcrypt (`bcryptjs`, pure JS, no native build)
- **Email:** Nodemailer welcome email on signup (falls back to a console log if no SMTP is configured)
- **Chatbot:** Lightweight retrieval engine — no external AI API key required. Matches messages against a static knowledge base (`src/knowledgeBase.js`) for policy/SLA/refund questions, and queries the `tickets` table directly for ticket-status questions. Off-topic questions are politely declined (the guardrail).

## Setup — the entire process

```bash
npm install
npm start
```

Then open **http://localhost:3000**.

No `createdb`, no database service, no password prompts, no build tools.
The first `npm start` creates `relay.db` in the project root automatically.

## Using the app
- **Create an account** or sign in.
- **Raise a ticket** with a subject, category, priority, and description.
- **Chat with the assistant** (bottom-right "Need Help?" button):
  - Policy: *"What is your refund policy?"*, *"What are your SLAs for urgent issues?"*, *"How do I escalate my issue?"*
  - Ticket status: *"What is the status of my ticket?"*
  - Guardrail test: ask something unrelated (*"write a python script"*) — the bot declines and redirects.

## Resetting your data
Delete `relay.db` from the project folder and restart the app.

## If you see "No such built-in module: node:sqlite"
Your Node.js version is too old. Run `node --version` — you need 22.13.0
or newer (or 24.x, which you likely have). Update Node from
https://nodejs.org if needed.

## Notes
- You'll see a one-line `ExperimentalWarning: SQLite is an experimental feature` in the console on startup — this is expected and harmless; the module works correctly despite the warning.
- Sessions use an HttpOnly, `SameSite=Lax` cookie — not accessible to client-side JS.
- Set `NODE_ENV=production` to mark the auth cookie `secure` (requires HTTPS).
